clear; close;

%% Parameters
M = 10;  % decimate by M

%% Create input signal and filter
%x = sin((1:10e4) * 2*pi/32);
x = sin(100 .^((1:10e4) * 2*pi/32 / 10000));
h = ones(250 * M, 1)/250/M; % length of h must be multiple of M!

%% Direct Form (Inefficient)
tic();
y = filter(h, 1, x);    % Compute filter output
y_dec = y(1:M:end);     % Throw away unneeded output samples
toc();

%% Polyphase Form (Efficient)
tic();
% Select polyphase filters
% equivalent to a vectorisation of:
%p0 = h(1:M:end);
%p1 = h(2:M:end);
%p2 = h(3:M:end);
%p3 = h(4:M:end);
p = zeros(M, length(h)/M);
for i = 1:M
    p(i, :) = h(i:M:end);
end

% Select polyphase signals
% equivalent to a vectorisation of:
% x0 = [x(1:4:end) 0];
% x1 = [0 x(4:4:end)];
% x2 = [0 x(3:4:end)];
% x3 = [0 x(2:4:end)];
x_dec = zeros(M, ceil(length(x)/M) + 1);
x_dec(1, :) = [x(1:M:end) 0];
for i = M:-1:2
    x_dec(M+2 - i, :) = [0 x(i:M:end)];
end

% filter each polyphase component and add together
% equivalent to a vectorisation of:
%y_poly_dec = filter(p0,1,x0) + filter(p1,1,x1)...
%           + filter(p2,1,x2) + filter(p3,1,x3);
y_poly_dec = 0;
for i = 1:M
    y_poly_dec = y_poly_dec + filter(p(i,:), 1, x_dec(i,:));
end
toc();

%% Plot
figure(1);
subplot(4,1,1); plot(x); title('x');
%subplot(4,1,2); plot(h); title('h');
%figure(2);
subplot(4,1,2); plot(y); title('y');
subplot(4,1,3); plot(y_dec); title('y decimated');
subplot(4,1,4); plot(y_poly_dec(1:end-1)); title('y poly decimated');
